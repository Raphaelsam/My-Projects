import time
from collections import deque
import matplotlib.pyplot as plt
import networkx as nx

class Graph:
    def __init__(self, vertices):
        self.num_vertices = vertices
        self.adj_matrix = [[0] * vertices for _ in range(vertices)]
        self.visited = [False] * vertices
        self.graph = nx.Graph()

    def add_edge(self, src, dest):
        self.adj_matrix[src][dest] = 1
        self.adj_matrix[dest][src] = 1  # For undirected graph
        self.graph.add_edge(src, dest)

    def reset_visited(self):
        self.visited = [False] * self.num_vertices

    def visualize_graph(self, current_node=None, delay=2.0):
        plt.clf()
        pos = nx.spring_layout(self.graph, seed=42)
        colors = ['green' if i == current_node else 'red' if self.visited[i] else 'blue'
                  for i in range(self.num_vertices)]
        nx.draw(self.graph, pos, with_labels=True, node_color=colors, 
                node_size=1000, font_size=10, font_weight='bold')
        plt.title("Graph Traversal Visualization", fontsize=14)
        plt.pause(delay)

    def visualize_forest(self, components):
        forest = nx.Graph()
        for component in components:
            for i in range(len(component)):
                forest.add_node(component[i])
                if i > 0:
                    forest.add_edge(component[i - 1], component[i])  # Link within component
        # Add dummy edges between components to visualize them in one layout
        for i in range(1, len(components)):
            forest.add_edge(components[i - 1][0], components[i][0])  # Connect first node of each component
        plt.clf()
        pos = nx.spring_layout(forest, seed=42)
        nx.draw(forest, pos, with_labels=True, node_color='blue', 
                node_size=1000, font_size=10, font_weight='bold')
        plt.title("Forest Visualization (Union of Disconnected Components)", fontsize=14)
        plt.show()

    def dfs_util(self, vertex, component):
        stack = [vertex]
        print(f"DFS starting at vertex {vertex}: ", end="")
        while stack:
            current = stack.pop()
            if not self.visited[current]:
                self.visited[current] = True
                component.append(current)
                print(current, end=" ")  # Print visited vertex
                self.visualize_graph(current_node=current)
                for i in range(self.num_vertices - 1, -1, -1):
                    if self.adj_matrix[current][i] == 1 and not self.visited[i]:
                        stack.append(i)
        print()  # Newline after completing component

    def perform_dfs(self):
        self.reset_visited()
        components = []
        plt.ion()
        for i in range(self.num_vertices):
            if not self.visited[i]:
                component = []
                self.dfs_util(i, component)
                components.append(component)
        plt.ioff()
        plt.show()
        print("Final Forest Visualization:")
        self.visualize_forest(components)
        print("All vertices visited in DFS:", [v for component in components for v in component])

    def bfs_util(self, vertex, component):
        queue = deque([vertex])
        self.visited[vertex] = True
        component.append(vertex)
        print(f"BFS starting at vertex {vertex}: ", end="")
        print(vertex, end=" ")  # Print starting vertex
        self.visualize_graph(current_node=vertex)
        while queue:
            current = queue.popleft()
            for i in range(self.num_vertices):
                if self.adj_matrix[current][i] == 1 and not self.visited[i]:
                    queue.append(i)
                    self.visited[i] = True
                    component.append(i)
                    print(i, end=" ")  # Print visited vertex
                    self.visualize_graph(current_node=i)
        print()  # Newline after completing component

    def perform_bfs(self):
        self.reset_visited()
        components = []
        plt.ion()
        for i in range(self.num_vertices):
            if not self.visited[i]:
                component = []
                self.bfs_util(i, component)
                components.append(component)
        plt.ioff()
        plt.show()
        print("Final Forest Visualization:")
        self.visualize_forest(components)
        print("All vertices visited in BFS:", [v for component in components for v in component])


if __name__ == "__main__":
    vertices = int(input("Enter the number of vertices in the graph: "))
    g = Graph(vertices)

    edges = int(input("Enter the number of edges: "))
    print("Enter the edges (source and destination):")
    for _ in range(edges):
        src, dest = map(int, input().split())
        g.add_edge(src, dest)

    while True:
        print("\nMenu:")
        print("1. Perform DFS")
        print("2. Perform BFS")
        print("3. Exit")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            start_time = time.time()
            g.perform_dfs()
            end_time = time.time()
            print(f"Time taken for DFS: {end_time - start_time:.6f} seconds")
        elif choice == 2:
            start_time = time.time()
            g.perform_bfs()
            end_time = time.time()
            print(f"Time taken for BFS: {end_time - start_time:.6f} seconds")
        elif choice == 3:
            print("Exiting...")
            break
        else:
            print("Invalid choice. Try again.")
