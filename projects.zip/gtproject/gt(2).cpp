#include <iostream>
#include <queue>
#include <stack>
#include <chrono>

#define MAX 20

using namespace std;

class Graph {
private:
    int adjMatrix[MAX][MAX];
    bool visited[MAX];
    int numVertices;

public:
    Graph(int vertices) {
        numVertices = vertices;
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                adjMatrix[i][j] = 0;
            }
            visited[i] = false;
        }
    }

    void addEdge(int src, int dest) {
        adjMatrix[src][dest] = 1;
        adjMatrix[dest][src] = 1; // For undirected graph
    }

    void resetVisited() {
        for (int i = 0; i < numVertices; i++) {
            visited[i] = false;
        }
    }

    void DFSUtil(int vertex) {
        stack<int> s;
        s.push(vertex);

        while (!s.empty()) {
            int current = s.top();
            s.pop();

            if (!visited[current]) {
                visited[current] = true;
                cout << current << " ";
            }

            // Push unvisited neighbors onto the stack
            for (int i = numVertices - 1; i >= 0; i--) {
                if (adjMatrix[current][i] == 1 && !visited[i]) {
                    s.push(i);
                }
            }
        }
    }

    void BFSUtil(int vertex) {
        queue<int> q;
        q.push(vertex);
        visited[vertex] = true;
        cout << vertex << " ";

        while (!q.empty()) {
            int current = q.front();
            q.pop();

            for (int i = 0; i < numVertices; i++) {
                if (adjMatrix[current][i] == 1 && !visited[i]) {
                    q.push(i);
                    visited[i] = true;
                    cout << i << " ";
                }
            }
        }
    }

    void performDFS() {
        resetVisited();
        cout << "DFS Traversal: ";
        for (int i = 0; i < numVertices; i++) {
            if (!visited[i]) {
                DFSUtil(i);
            }
        }
        cout << endl;
    }

    void performBFS() {
        resetVisited();
        cout << "BFS Traversal: ";
        for (int i = 0; i < numVertices; i++) {
            if (!visited[i]) {
                BFSUtil(i);
            }
        }
        cout << endl;
    }
};

int main() {
    int vertices, edges, src, dest, choice;

    cout << "Enter the number of vertices in the graph: ";
    cin >> vertices;

    Graph g(vertices);

    cout << "Enter the number of edges: ";
    cin >> edges;

    cout << "Enter the edges (source and destination):\n";
    for (int i = 0; i < edges; i++) {
        cin >> src >> dest;
        g.addEdge(src, dest);
    }

    do {
        cout << "\nMenu:\n";
        cout << "1. Perform DFS\n";
        cout << "2. Perform BFS\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            auto start = chrono::high_resolution_clock::now();
            g.performDFS();
            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;
            cout << "Time taken for DFS: " << elapsed.count() << " seconds\n";
            break;
        }
        case 2: {
            auto start = chrono::high_resolution_clock::now();
            g.performBFS();
            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;
            cout << "Time taken for BFS: " << elapsed.count() << " seconds\n";
            break;
        }
        case 3:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 3);

    return 0;
}

