import time
from collections import deque
import matplotlib.pyplot as plt
import networkx as nx

class Graph:
    def __init__(self, vertices):
        self.num_vertices = vertices
        self.adj_matrix = [[0] * vertices for _ in range(vertices)]
        self.visited = [False] * vertices
        self.graph = nx.Graph()
        self.dfs_result = []  # To store DFS traversal order
        self.bfs_result = []  # To store BFS traversal order

    def add_edge(self, src, dest):
        self.adj_matrix[src][dest] = 1
        self.adj_matrix[dest][src] = 1  # For undirected graph
        self.graph.add_edge(src, dest)

    def reset_visited(self):
        self.visited = [False] * self.num_vertices

    def visualize_graph(self, current_node=None, delay=2.0):  # Fixed delay to 2 seconds
        plt.clf()
        pos = nx.spring_layout(self.graph, seed=42)  # Fixed layout for consistency
        colors = ['green' if i == current_node else 'red' if self.visited[i] else 'blue'
                  for i in range(self.num_vertices)]
        nx.draw(self.graph, pos, with_labels=True, node_color=colors, 
                node_size=1000, font_size=10, font_weight='bold')
        plt.title("Graph Traversal Visualization", fontsize=14)
        plt.pause(delay)

    def dfs_util(self, vertex):
        stack = [vertex]
        while stack:
            current = stack.pop()
            if not self.visited[current]:
                self.visited[current] = True
                self.dfs_result.append(current)  # Record DFS traversal order
                self.visualize_graph(current_node=current)
                # Push unvisited neighbors onto the stack
                for i in range(self.num_vertices - 1, -1, -1):
                    if self.adj_matrix[current][i] == 1 and not self.visited[i]:
                        stack.append(i)

    def bfs_util(self, vertex):
        queue = deque([vertex])
        self.visited[vertex] = True
        self.visualize_graph(current_node=vertex)
        while queue:
            current = queue.popleft()
            self.bfs_result.append(current)  # Record BFS traversal order
            # Enqueue unvisited neighbors
            for i in range(self.num_vertices):
                if self.adj_matrix[current][i] == 1 and not self.visited[i]:
                    queue.append(i)
                    self.visited[i] = True
                    self.visualize_graph(current_node=i)

    def perform_dfs(self):
        self.reset_visited()
        self.dfs_result = []  # Clear previous results
        plt.ion()  # Interactive mode for visualization
        for i in range(self.num_vertices):
            if not self.visited[i]:
                self.dfs_util(i)
        plt.ioff()
        plt.show()

    def perform_bfs(self):
        self.reset_visited()
        self.bfs_result = []  # Clear previous results
        plt.ion()  # Interactive mode for visualization
        for i in range(self.num_vertices):
            if not self.visited[i]:
                self.bfs_util(i)
        plt.ioff()
        plt.show()

    def display_combined_results(self):
        print("\nCombined Traversals:")
        print("DFS Order: ", " -> ".join(map(str, self.dfs_result)))
        print("BFS Order: ", " -> ".join(map(str, self.bfs_result)))


if __name__ == "__main__":
    vertices = int(input("Enter the number of vertices in the graph: "))
    g = Graph(vertices)

    edges = int(input("Enter the number of edges: "))
    print("Enter the edges (source and destination):")
    for _ in range(edges):
        src, dest = map(int, input().split())
        g.add_edge(src, dest)

    while True:
        print("\nMenu:")
        print("1. Perform DFS")
        print("2. Perform BFS")
        print("3. Display Combined Traversals")
        print("4. Exit")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            start_time = time.time()
            g.perform_dfs()
            end_time = time.time()
            print(f"Time taken for DFS: {end_time - start_time:.6f} seconds")
        elif choice == 2:
            start_time = time.time()
            g.perform_bfs()
            end_time = time.time()
            print(f"Time taken for BFS: {end_time - start_time:.6f} seconds")
        elif choice == 3:
            g.display_combined_results()
        elif choice == 4:
            print("Exiting...")
            break
        else:
            print("Invalid choice. Try again.")
