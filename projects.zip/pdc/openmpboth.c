#include <stdio.h>
#include <omp.h>
#include<stdlib.h>
#include<math.h>
#include <unistd.h>
double function(const double x)
{
	return 2/(1+(x*x));
}

//structure for storing result of all threads
struct Result
{
	double duration, area;
};

//RectangleMethod
const struct Result rectangleMethod(const double a, const double b, const int N, const int nThreads)
{
	//initialization
	struct Result r ;
	const double h = ((b - a) / N);
	int i;
	double start = omp_get_wtime();
	double sum = 0;
    
	//loop for computing sum of all intervals
	#pragma omp parallel for num_threads(nThreads) shared (a, N, h) private(i) reduction(+: sum)
	for (i = 1; i <= N; i++){
		 sum += function(a + i * h);
		}

	sum *= h;
	//storing results in resultant structure
	r.area = sum;
	r.duration = omp_get_wtime() - start; 
	return r;
}

//TrapezoidalMethod
const struct Result trapezoidalMethod(const double a, const double b, const int N, const int nThreads)
{
	//initialization
	struct Result r ;
    int i;
	const double h = ((b - a) / N);
	double start = omp_get_wtime();
	double sum = 0;

	//loop for computing sum of all intervals
	#pragma omp parallel for num_threads(nThreads) shared (a, N, h) private(i) reduction(+: sum)
	for (i = 1; i < N; i++){
		 sum += function(a + i * h);
		}
	
	//using formula of trapezoidal method
	sum = (2*sum + function(a) + function(b)) * (h/2);

	//storing results in resultant structure
	r.area = sum;
	r.duration = omp_get_wtime() - start; 
	
	//return the final resultant structure
	return r;
}

//main
int main()
{
	//initialization
	const short maxThreads = 2; 
	double a, b;
	double ttime=0;
    int N,i,method;
	printf("==============\t Numerical Integration Using OpenMp \t====================\n");
	printf("\n Select the method\n 1 - Rectangle\n 2 - Trapezoidal Rule\nChoice: "); 
	scanf("%d",&method) ;

	printf("   a: ");
	scanf("%lf",&a);
	printf("   b: ");
	scanf("%lf",&b);
	printf("   N: ");
	scanf("%d",&N);

	//array for storing results of all threads
    struct Result result[maxThreads];

	//loop for computing the results
	for (int i = 0; i < maxThreads; i++)
	{
      if(method == 1)
	  { result[i] = rectangleMethod(a, b, N, i + 1);}
      else if(method == 2)
	  {  result[i] = trapezoidalMethod(a, b, N, i + 1);}
      else{exit(1);}
	} 
   
    //to get results for each no. of threads
	for(i=0; i<maxThreads; i++)
	{
	
	
		printf("Threads:  %d\t" , i+1); 
		printf("Time Interval: %f\t\t", result[i].duration); 
		printf("Area:  %f\n", result[i].area); 
		ttime+= result[i].duration;
        sleep(1);
	}
	
	printf("total time taken by the method of OPENMP --> %f \n",ttime);
			
	return 0;
}
