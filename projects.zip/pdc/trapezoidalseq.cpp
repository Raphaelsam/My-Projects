#include <iostream>
#include <iomanip>
#include <math.h>

#include <algorithm>
#include <chrono>
#include <iostream>
#include<vector>
using namespace std;
using namespace std::chrono;


float y(float x){
    return 2/(1+pow(x,2));
}

int main(){
    float x0, xn, h, s;
    int i,n;
    
    
    

    
    
    
    
    
    
    
    cout << "Enter lower limit: ";
	cin>>x0;
	 cout << "Enter upper limit: ";
	cin>>xn;
	cout<<"Enter number of subintervals: ";
    cin >> n;
    cout << fixed;
    
    
  
    // Get starting timepoint
    auto start = high_resolution_clock::now();
    
    
    h = (xn-x0)/n;
    s = y(x0)+y(xn);
    for (i=1;i<=n-1;i++)
        s += 2*y(x0+i*h);
    cout << "Result of integration is: "
        << setw(6) << setprecision(4)
        << (h/2)*s << endl;
        
        auto stop = high_resolution_clock::now();
        
        
        // Get duration. Substart timepoints to 
    // get durarion. To cast it to proper unit
    // use duration cast method
    auto duration = duration_cast<microseconds>(stop - start);
//  duration = duration / 1000000;
    cout << "\nTime taken by function: "
         << duration.count() << " microseconds" << endl;
        
        
        
    return 0;
}
