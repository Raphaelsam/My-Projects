#include <iostream>
#include <iomanip>
#include <math.h>
#include <algorithm>
#include <chrono>
#include <iostream>
#include<vector>
using namespace std;
using namespace std::chrono;


inline double f(double x) {
  return 2/(1+pow(x,2));
}

double integrateRect(double start, double stop, int divs) {
  double h, i, ans = 0;
  
  
  

  h = (stop - start) / divs;
  for (i = start; i < stop; i += h)
    ans += f(i + 0.5 * h) * h;
    
   
  return ans;
}


int main() {
  int N;
  double a, b;

  cout << "Enter start limit: ";
  cin >> a;
  cout << "Enter end limit: ";
  cin >> b;
  cout << "Enter number of intervals: ";
  cin >> N;
  
    
    // Get starting timepoint
    auto start = high_resolution_clock::now();

  cout << "\nResult of Integration = " << integrateRect(a, b, N) << "\n\n";
  
       auto stop = high_resolution_clock::now();
        
        
        // Get duration. Substart timepoints to 
    // get durarion. To cast it to proper unit
    // use duration cast method
    auto duration = duration_cast<microseconds>(stop - start);
//  duration = duration / 1000000;
    cout << "\nTime taken by function: "
         << duration.count() << " microseconds" << endl;
     
  
  return 0;
}
