import os
import json
import math
import matplotlib.pyplot as plt
from tkinter import Tk, Label, Button, Listbox, Scrollbar, messagebox, Frame, Text, END, BOTH, LEFT, RIGHT, Y
from typing import List, Tuple
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


OUTPUT_FOLDER = r"C:\Users\User\Desktop\daaproj2\output"  
if not os.path.exists(OUTPUT_FOLDER):
    os.makedirs(OUTPUT_FOLDER)


class Point:
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point(x={self.x}, y={self.y})"


class ClosestPairApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Closest Pair and Integer Multiplication")
        self.root.geometry("800x600")
        self.root.configure(bg="#f0f0f0")

        
        self.title_label = Label(root, text="Closest Pair Finder", font=("Arial", 18, "bold"), bg="#f0f0f0", fg="#333")
        self.title_label.pack(pady=10)

       
        self.instructions_label = Label(root, text="Select a file to process and view results", font=("Arial", 12), bg="#f0f0f0", fg="#555")
        self.instructions_label.pack(pady=5)

        
        self.file_frame = Frame(root, bg="#f0f0f0")
        self.file_frame.pack(pady=10)

        self.listbox = Listbox(self.file_frame, width=50, height=15, font=("Arial", 10))
        self.scrollbar = Scrollbar(self.file_frame, command=self.listbox.yview)
        self.listbox.config(yscrollcommand=self.scrollbar.set)
        self.listbox.pack(side=LEFT, fill=BOTH, expand=True)
        self.scrollbar.pack(side=RIGHT, fill=Y)

        
        self.button_frame = Frame(root, bg="#f0f0f0")
        self.button_frame.pack(pady=10)

        self.load_button = Button(self.button_frame, text="Load Files", command=self.load_files, width=15, bg="#0078d7", fg="white")
        self.load_button.grid(row=0, column=0, padx=5)

        self.process_button = Button(self.button_frame, text="Process File", command=self.process_file, width=15, bg="#28a745", fg="white")
        self.process_button.grid(row=0, column=1, padx=5)

        self.exit_button = Button(self.button_frame, text="Exit", command=root.quit, width=15, bg="#dc3545", fg="white")
        self.exit_button.grid(row=0, column=2, padx=5)

       
        self.result_frame = Frame(root, bg="#f0f0f0")
        self.result_frame.pack(pady=10, fill=BOTH, expand=True)

        self.result_text = Text(self.result_frame, wrap="word", height=10, font=("Courier", 10))
        self.result_text.pack(side=LEFT, fill=BOTH, expand=True)

        self.result_scrollbar = Scrollbar(self.result_frame, command=self.result_text.yview)
        self.result_text.config(yscrollcommand=self.result_scrollbar.set)
        self.result_scrollbar.pack(side=RIGHT, fill=Y)

        
        self.figure_canvas = None

    def load_files(self):
        """Load files from the OUTPUT_FOLDER into the Listbox."""
        self.listbox.delete(0, "end")
        files = [f for f in os.listdir(OUTPUT_FOLDER) if os.path.isfile(os.path.join(OUTPUT_FOLDER, f))]
        for file in files:
            self.listbox.insert("end", file)

    def process_file(self):
        """Process the selected file."""
        try:
            selected_file = self.listbox.get(self.listbox.curselection())
        except:
            messagebox.showerror("Error", "No file selected!")
            return

        file_path = os.path.join(OUTPUT_FOLDER, selected_file)

        
        self.result_text.delete(1.0, END)
        if self.figure_canvas:
            self.figure_canvas.get_tk_widget().destroy()

        if "multiplication" in selected_file:
            
            with open(file_path, "r") as file:
                content = file.read().strip()
                a, b = map(int, content.split())
                result, steps = div_and_conq_with_steps(a, b)
            self.result_text.insert(END, f"Result using Divide-and-Conquer:\n\n")
            for step in steps:
                self.result_text.insert(END, step + "\n")
            self.result_text.insert(END, f"\nFinal Result: {result}\n")
        elif "closest_pair_input" in selected_file:
            
            points = []
            with open(file_path, "r") as f:
                for line in f:
                    x, y = map(float, line.strip().split())
                    points.append(Point(x, y))

            closest_points, min_dist = closest_pair(points)

            
            self.result_text.insert(
                END,
                f"Closest Points: {closest_points[0]} and {closest_points[1]}\n"
                f"Minimum Distance: {min_dist:.6f}\n"
            )

           
            fig, ax = plt.subplots()
            ax.scatter([p.x for p in points], [p.y for p in points], label="Points")
            ax.plot(
                [closest_points[0].x, closest_points[1].x],
                [closest_points[0].y, closest_points[1].y],
                color="red",
                label="Closest Pair"
            )
            ax.set_title("Closest Pair Visualization")
            ax.grid(True)
            ax.legend()

            self.figure_canvas = FigureCanvasTkAgg(fig, master=self.result_frame)
            self.figure_canvas.get_tk_widget().pack(fill=BOTH, expand=True)
            self.figure_canvas.draw()
        elif "points_input" in selected_file:
            # Read and display points from a points_input file
            points = []
            with open(file_path, "r") as file:
                for line in file:
                    x, y = map(float, line.strip().split())
                    points.append(Point(x, y))
            
            # Display points in the result text box
            self.result_text.insert(END, "Points in the file:\n")
            for point in points:
                self.result_text.insert(END, f"{point}\n")
           
        else:
            messagebox.showerror("Error", "Unsupported file type.")

# Helper functions for the closest pair algorithm
def closest_pair(points: List[Point]) -> Tuple[Tuple[Point, Point], float]:
    points.sort(key=lambda p: p.x)
    return closest_pair_recursive(points)

def closest_pair_recursive(points: List[Point]) -> Tuple[Tuple[Point, Point], float]:
    if len(points) <= 3:
        return brute_force_closest_pair(points)

    mid = len(points) // 2
    mid_point = points[mid]

    left_closest, left_dist = closest_pair_recursive(points[:mid])
    right_closest, right_dist = closest_pair_recursive(points[mid:])

    if left_dist < right_dist:
        closest_pair, min_dist = left_closest, left_dist
    else:
        closest_pair, min_dist = right_closest, right_dist

    strip = [p for p in points if abs(p.x - mid_point.x) < min_dist]
    strip_closest, strip_dist = closest_in_strip(strip, min_dist)

    if strip_dist < min_dist:
        closest_pair, min_dist = strip_closest, strip_dist

    return closest_pair, min_dist

def brute_force_closest_pair(points: List[Point]) -> Tuple[Tuple[Point, Point], float]:
    min_dist = float("inf")
    closest_pair = None
    for i in range(len(points)):
        for j in range(i + 1, len(points)):
            dist = distance(points[i], points[j])
            if dist < min_dist:
                min_dist = dist
                closest_pair = (points[i], points[j])
    return closest_pair, min_dist

def closest_in_strip(strip: List[Point], d: float) -> Tuple[Tuple[Point, Point], float]:
    strip.sort(key=lambda p: p.y)
    min_dist = d
    closest_pair = None

    for i in range(len(strip)):
        for j in range(i + 1, len(strip)):
            if strip[j].y - strip[i].y >= min_dist:
                break
            dist = distance(strip[i], strip[j])
            if dist < min_dist:
                min_dist = dist
                closest_pair = (strip[i], strip[j])
    return closest_pair, min_dist

def distance(p1: Point, p2: Point) -> float:
    return math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2)

# Helper functions for Divide-and-Conquer multiplication
def div_and_conq_with_steps(x: int, y: int) -> Tuple[int, List[str]]:
    """Performs Divide-and-Conquer multiplication with steps logged."""
    steps = []
    result = div_and_conq_recursive(x, y, steps)
    return result, steps

def div_and_conq_recursive(x: int, y: int, steps: List[str]) -> int:
    """Recursive Divide-and-Conquer multiplication."""
    if x < 10 or y < 10:
        result = x * y
        steps.append(f"Base case: {x} * {y} = {result}")
        return result

    n = max(len(str(x)), len(str(y)))
    m = n // 2

    high1, low1 = divmod(x, 10 ** m)
    high2, low2 = divmod(y, 10 ** m)

    steps.append(f"Split {x} into {high1} and {low1}")
    steps.append(f"Split {y} into {high2} and {low2}")

    z0 = div_and_conq_recursive(low1, low2, steps)
    z1 = div_and_conq_recursive((low1 + high1), (low2 + high2), steps)
    z2 = div_and_conq_recursive(high1, high2, steps)

    result = (z2 * 10 ** (2 * m)) + ((z1 - z2 - z0) * 10 ** m) + z0
    steps.append(f"Divide-and-Conquer result for {x} * {y}: {result}")

    return result

if __name__ == "__main__":
    root = Tk()
    app = ClosestPairApp(root)
    root.mainloop()
