import os
import random
import time

# Seed for random number generation
random.seed(int(time.time()))

# Function to generate a random 4-digit number
def get_random_4_digit_number():
    return random.randint(1000, 9999)

def main():
    os.makedirs("output", exist_ok=True)

    # Generate Closest Pair of Points Data
    for i in range(1, 11):
        points_filename = f"output/points_input_{i}.txt"
        with open(points_filename, "w") as points_file:
            for _ in range(10):  # Generate fewer points for simplicity
                x = get_random_4_digit_number()  # 4-digit x-coordinate
                y = get_random_4_digit_number()  # 4-digit y-coordinate
                points_file.write(f"{x} {y}\n")
        # Display generated file content
        print(f"Generated {points_filename}:")
        with open(points_filename, "r") as file:
            print(file.read())

    # Generate Integer Multiplication Data
    for i in range(1, 11):
        mult_filename = f"output/multiplication_input_{i}.txt"
        with open(mult_filename, "w") as mult_file:
            a = get_random_4_digit_number()  # 4-digit number
            b = get_random_4_digit_number()  # 4-digit number
            mult_file.write(f"{a} {b}\n")
        # Display generated file content
        print(f"Generated {mult_filename}:")
        with open(mult_filename, "r") as file:
            print(file.read())

    print("Files generated successfully.")

if __name__ == "__main__":
    main()
