import random
import math
import json
import os
from typing import List, Tuple

class Point:
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point(x={self.x}, y={self.y})"


# Function to generate random points within a range with values rounded to 4 decimal places
def generate_points(num_points: int, coord_range: int) -> List[Point]:
    # Generate points with values rounded to 4 decimal places
    return [Point(round(random.uniform(0, coord_range), 4), round(random.uniform(0, coord_range), 4)) for _ in range(num_points)]


# Function to calculate the distance between two points
def distance(p1: Point, p2: Point) -> float:
    return math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2)


# Brute-force method to find the closest pair of points
def brute_force_closest_pair(points: List[Point]) -> Tuple[Tuple[Point, Point], float]:
    min_dist = float('inf')
    closest_pair = (None, None)
    for i in range(len(points)):
        for j in range(i + 1, len(points)):
            dist = distance(points[i], points[j])
            if dist < min_dist:
                min_dist = dist
                closest_pair = (points[i], points[j])
    return closest_pair, min_dist


# Recursive function to find the closest pair in a strip
def closest_in_strip(strip: List[Point], min_dist: float) -> Tuple[Tuple[Point, Point], float]:
    if len(strip) < 2:
        return None, float('inf')  # Return a dummy value if the strip is too small

    strip.sort(key=lambda p: p.y)
    closest_pair = (strip[0], strip[1])
    for i in range(len(strip)):
        for j in range(i + 1, len(strip)):
            if (strip[j].y - strip[i].y) >= min_dist:
                break
            dist = distance(strip[i], strip[j])
            if dist < min_dist:
                min_dist = dist
                closest_pair = (strip[i], strip[j])

    return closest_pair, min_dist


# Recursive function to find the closest pair of points
def closest_pair_recursive(points: List[Point], left: int, right: int) -> Tuple[Tuple[Point, Point], float]:
    if right - left <= 3:
        return brute_force_closest_pair(points[left:right])
    
    mid = (left + right) // 2
    mid_point = points[mid]

    left_closest, left_dist = closest_pair_recursive(points, left, mid)
    right_closest, right_dist = closest_pair_recursive(points, mid, right)

    if left_dist < right_dist:
        closest_pair, min_dist = left_closest, left_dist
    else:
        closest_pair, min_dist = right_closest, right_dist

    strip = [p for p in points[left:right] if abs(p.x - mid_point.x) < min_dist]
    strip_closest, strip_dist = closest_in_strip(strip, min_dist)
    
    if strip_dist < min_dist:
        closest_pair, min_dist = strip_closest, strip_dist

    return closest_pair, min_dist


# Closest pair algorithm that sorts points and then calls the recursive function
def closest_pair(points: List[Point]) -> Tuple[Tuple[Point, Point], float]:
    points.sort(key=lambda p: p.x)
    return closest_pair_recursive(points, 0, len(points))


# Main function to generate input, run algorithm, and save output
def main():
    os.makedirs("output", exist_ok=True)

    for i in range(1, 11):
        # Generate random points with smaller values rounded to 4 decimal places
        points = generate_points(100 + i * 10, 100)  # Adjusted coord_range to 100

        # Write input points to file
        input_filename = f"output/closest_pair_input_{i}.txt"
        with open(input_filename, "w") as input_file:
            for point in points:
                input_file.write(f"{point.x} {point.y}\n")

        # Apply the closest pair algorithm
        closest_points, min_dist = closest_pair(points)

        # Write output results to file
        output_filename = f"output/closest_pair_output_{i}.json"
        with open(output_filename, "w") as output_file:
            json.dump({
                "point1": {"x": closest_points[0].x, "y": closest_points[0].y},
                "point2": {"x": closest_points[1].x, "y": closest_points[1].y},
                "distance": round(min_dist, 6)
            }, output_file, indent=2)

        # Print results to console
        print(f"Iteration {i}:")
        print(f"Closest Pair: ({closest_points[0].x:.4f}, {closest_points[0].y:.4f}) and ({closest_points[1].x:.4f}, {closest_points[1].y:.4f})")
        print(f"Distance: {min_dist:.6f}")
        print(f"Input file: {input_filename}")
        print(f"Output file: {output_filename}\n")

    print("Files generated and closest pair calculated successfully.")


if __name__ == "__main__":
    main()
